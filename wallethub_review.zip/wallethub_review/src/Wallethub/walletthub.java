package Wallethub;

import java.io.File;
import java.io.IOException;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.bcel.generic.Select;
import org.apache.commons.io.FileUtils;

public class walletthub {
	public static void main(String[] args) throws InterruptedException {

		//Creating reference of Webdriver Interface
		WebDriver driver;
		//Declare wallet hub Credentials
        String user = "saranyakrishnan8086@gmail.com";
		
		String pass = "Saranya@06";

		//Creating an instance of chrome level class to disable browser level notifications
		ChromeOptions coptions = new ChromeOptions();
		coptions.addArguments("--disable-notifications");

		// Telling Selenium to find Chrome Driver
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saran\\eclipse-workspace\\facee\\drivers\\chromedriver.exe");

		// Initialize browser
		driver = new ChromeDriver(coptions);

		// Launch wallethub
		driver.get("http://wallethub.com/profile/test_insurance_company/");

		//Maximize Window
		driver.manage().window().maximize();

		
		//Wait
		Thread.sleep(2000);
		
		
		WebElement login = driver.findElement(By.xpath("//*[@id=\"web-app\"]/header/div/nav[1]/span"));
		login.click();
		Thread.sleep(2000);
		//Enter Username
		WebElement userTextField = driver.findElement(By.xpath("/html/body/main/div/form/div[1]/input"));
		userTextField.sendKeys(user);

		//Wait
		Thread.sleep(2000);

		//Enter Password
		WebElement PassTextField = driver.findElement(By.xpath("//*[@id=\"password\"]"));
		PassTextField.sendKeys(pass);

		//Wait
		Thread.sleep(2000);

		//Click on Login button
		driver.findElement(By.xpath("//*[@id=\"join-login\"]/form/div[4]/button[2]")).click();

		//navigating to insurance company
		Thread.sleep(10000);
	    
		driver.get("http://wallethub.com/profile/test_insurance_company/");

		//Add review option
		WebElement addreview= driver.findElement(By.xpath("/html/body/web-app/div/div[1]/main/div[1]/nav/div[3]/button[1]"));
		addreview.click();
		//Click on What's on Your Mind?
		

		//star filling and checking
		Actions action = new Actions(driver);
		WebElement ratingStar = driver.findElement(By.className("rating-box-wrapper"));
		action.moveToElement(ratingStar).perform();
		WebElement ratingstarfilled = driver.findElement(By.xpath("/html/body/web-app/div/div[1]/main/div[2]/div/div[3]/section/modal-dialog/div/div/write-review/review-star/div/svg[4]"));
		if(ratingstarfilled.isDisplayed())
		{
			ratingstarfilled.click();
		}
		
		WebElement TextArea = driver.findElement(By.xpath("/html/body/web-app/div/div[1]/main/div[2]/div/div[3]/section/modal-dialog/div/div/write-review/div/div[1]/textarea"));
		TextArea.click();
		TextArea.sendKeys("very helpful and very user friendly, at any time of accidents the service is providing exactly helpful, Buy Branded Tablets online at myG Digital Hub. Exclusive Offer for top Tablet brands. Why settle for less when you can have more? Shop for the best varieties of tablets. 100% Purchase Protection. myG Big Saving. Special Price. New Deals Everyday. Brands: Smart Phones, Smart TV, Camera, Laptop, Computer, Tabl");
		Thread.sleep(3000);
		WebElement dropdown = driver.findElement(By.xpath("//*[@id=\"reviews-section\"]/modal-dialog/div/div/write-review/div/ng-dropdown/div/span"));
		//dropdown.findElement(By.xpath("//*[@id=\"reviews-section\"]/modal-dialog/div/div/write-review/div/ng-dropdown/div/ul/li[2]")).click();
		dropdown.click();
		WebElement dropdownlist = driver.findElement(By.xpath("//*[@id=\"reviews-section\"]/modal-dialog/div/div/write-review/div/ng-dropdown/div/ul/li[2]"));
		dropdownlist.click();
		WebElement submit = driver.findElement(By.xpath("//*[@id=\"reviews-section\"]/modal-dialog/div/div/write-review/sub-navigation/div/div[2]"));
		submit.click();
		
		//Wait
		Thread.sleep(3000);

		
		
		driver.close();



}

	private static Object fills() {
		// TODO Auto-generated method stub
		return null;
	}
}