package facee;

import java.io.File;
import java.io.IOException;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.commons.io.FileUtils;

public class facewe {
	public static void main(String[] args) throws InterruptedException, IOException {

		//Creating reference of Webdriver Interface
		WebDriver driver;

		//Declare Facebook Credentials
		String user = JOptionPane.showInputDialog(
                "What is your username?");
		
		String pass = JOptionPane.showInputDialog(
                "What is your password?");

		//Creating an instance of chrome level class to disable browser level notifications
		ChromeOptions coptions = new ChromeOptions();
		coptions.addArguments("--disable-notifications");

		// Telling Selenium to find Chrome Driver
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saran\\eclipse-workspace\\facee\\drivers\\chromedriver.exe");

		// Initialize browser
		driver = new ChromeDriver(coptions);

		// Launch Facebook
		driver.get("http://facebook.com/");

		//Wait
		Thread.sleep(1000);

		//Maximize Window
		driver.manage().window().maximize();

		//Wait
		Thread.sleep(2000);

		//Enter Username
		WebElement userTextField = driver.findElement(By.id("email"));
		userTextField.sendKeys(user);

		//Wait
		Thread.sleep(2000);

		//Enter Password
		WebElement PassTextField = driver.findElement(By.id("pass"));
		PassTextField.sendKeys(pass);

		//Wait
		Thread.sleep(2000);

		//Click on Login button
		driver.findElement(By.name("login")).click();

		//Wait
		Thread.sleep(10000);

		//Click on Accept All Cookies button
		WebElement webElement = driver.findElement(By.cssSelector("div[aria-label=\"Create a post\""));
				webElement.click();

		//In case if the browser shows - Click on Not Now for Remember Password button
		//WebElement element = driver.findElement(By.cssSelector("div[aria-label="Not Now"]:nth-child(2)"));
		//element.click();

		//Click on What's on Your Mind?
		WebElement TextArea = driver.findElement(By.cssSelector("div[role=\"button\"] > div > span[style*=\"webkit-box-orient\"]"));
		TextArea.click();
		Thread.sleep(3000);

		//Click on the expanded text area
		WebElement TextAreaExpanded = driver.findElement(By.cssSelector("div[aria-describedby*=\"placeholder\"]"));
		TextAreaExpanded.click();
		TextAreaExpanded.sendKeys("Hello World");

		//Wait
		Thread.sleep(3000);

		//Click On Post Button
		WebElement PostBtn = driver.findElement(By.cssSelector("div[aria-label=\"Post\"]"));
		PostBtn.click();

		//Wait
		Thread.sleep(4000);

		// Take Screenshot for Evidence
		File srce = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		
		WebElement account_logout = driver.findElement(By.cssSelector("div[aria-label=\"Account\"]"));
		account_logout.click();
		//WebDriverWait wait = new WebDriverWait(driver, 8);
		WebElement logout = driver.findElement(By.cssSelector("div[dir=\"auto\""));
		logout.click();
		
		driver.close();



}
}